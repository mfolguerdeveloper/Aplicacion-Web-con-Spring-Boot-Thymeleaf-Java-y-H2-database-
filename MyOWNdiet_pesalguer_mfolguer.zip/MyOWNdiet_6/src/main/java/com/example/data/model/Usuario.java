package com.example.data.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Usuario {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id_usuario;
	private String name;
	private String email;
	private String passwd;
	private String confirpasswd;
	private float peso;
	private int edad;
	private float altura;
	private char genero;
	
	@ManyToMany (mappedBy ="usuarios",cascade = CascadeType.ALL , fetch = FetchType.EAGER)
	private List<Comida> favoritas = new ArrayList<Comida>();

	@ManyToOne 
	private Dieta dieta;
	
   public Usuario() {
		this.name = "";
		this.email = "";
		this.peso = 0;
		this.edad = 0;
		this.altura = 0;
		this.genero = 'm';		
	}

	public Usuario( String name, String email, float peso, int edad, float altura, char genero) {
		
		this.name = name;
		this.email = email;
		this.peso = peso;
		this.edad = edad;
		this.altura = altura;
		this.genero = genero;
	
	}
	

	public long getId() {
		return id_usuario;
	}


	public void setId(long id) {
		this.id_usuario = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public Dieta getDieta() {
		return dieta;
	}


	public void setDieta(Dieta dieta) {
		this.dieta = dieta;
	}
	
	public long getId_usuario() {
		return id_usuario;
	}

	public void setId_usuario(long id_usuario) {
		this.id_usuario = id_usuario;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura = altura;
	}

	public char getGenero() {
		return genero;
	}

	public void setGenero(char genero) {
		this.genero = genero;
	}
	

	public String getPasswd() {
		return passwd;
	}

	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	

	public String getConfirpasswd() {
		return confirpasswd;
	}

	public void setConfirpasswd(String confirpasswd) {
		this.confirpasswd = confirpasswd;
	}

	public List<Comida> getFavoritas() {
		return favoritas;
	}

	public void setFavoritas(List<Comida> favoritas) {
		this.favoritas = favoritas;
	}

	public void addFavorita(Comida c){
		favoritas.add(c);
		c.getUsuarios().add(this);
	}
	
	public void eliminarFavorita(Comida c){
		favoritas.remove(c);
		c.getUsuarios().remove(this);
	}
	
	public void addDieta(Dieta d) {
		d.addUsuario(this);
		this.setDieta(d);
	}
	
	public void eliminarDieta(Dieta d) {
		this.setDieta(null);
		d.eliminarUsuario(this);
	}
	
	
	public void eliminarFavoritos() {
		for (Iterator<Comida> iterator = favoritas.iterator(); iterator.hasNext();) {
			Comida comida = (Comida) iterator.next();
			for (int i = 0; i < comida.getUsuarios().size(); i++) {
				Usuario u = (Usuario) comida.getUsuarios().get(i);
				if(u.equals(this)) {
					comida.getUsuarios().remove(u);
				}
			}
		}
		this.setFavoritas(null);
	}


	@Override
	public String toString() {
		return "Usuario [id=" + id_usuario + ", name=" + name + ", email=" + email + ",password=" + passwd +"Favoritas:"+favoritas.toString()+ "]";
	}
	

	
}
