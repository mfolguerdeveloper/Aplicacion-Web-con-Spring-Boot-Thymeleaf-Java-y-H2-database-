package com.example.data.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.data.model.Comida;
import com.example.data.model.Dieta;
import com.example.data.model.Usuario;
import com.example.data.service.ComidaService;
import com.example.data.service.DietaService;
import com.example.data.service.UsuarioService;


@Controller
@RequestMapping("/user")
public class UsuarioController {

	private final UsuarioService usuarioService;

	private final DietaService dietaService;

	private final ComidaService comidaService;

	@Autowired
	public UsuarioController(UsuarioService usuarioService,DietaService dietaService,ComidaService comidaService) {
		super();
		this.usuarioService = usuarioService;
		this.dietaService = dietaService;
		this.comidaService = comidaService;
		System.out.println("\t Constructor UsuarioController ");
	}

	@GetMapping("/index")
	public String index(Model model) {	
		System.out.println("\t UsuarioController::Principal");
		return "index";
	}

	@GetMapping("/index/{id}")
	public String indexVerificado(@PathVariable("id") Long usuarioId,Model model) {	
		System.out.println("\t UsuarioController::Principal registrado");
		Usuario u = usuarioService.findUsuarioById(usuarioId);
		model.addAttribute("usuario", u);
		return "index2";
	}


	/**
    LISTAR USUARIOS     
	 */
	@GetMapping("/listarUsuarios")
	public String showUsersTable(Model model) {
		System.out.println("\t UsuarioController::showUsersTable");    	    	    	
		List<Usuario> usuarioList = (List<Usuario>) usuarioService.findAllUsers(); 
		model.addAttribute("usuarios", usuarioList.isEmpty() ? Collections.EMPTY_LIST : usuarioList);        
		return "listarUsuarios"; //devuelve la vista a renderizar
	}

	//Para redireccionar al HTML
	@GetMapping("/addUsuario")
	public String showAddUsuarioForm(Usuario usuario) {    	
		System.out.println("\t UsuarioController::showAddUsuarioForm");   

		return "addUsuario";
	}
	//Este para pasar parametros
	@PostMapping("/addUsuario")    
	public String addUsuario(Usuario usuario, Model model){
		System.out.println("\t UsuarioController::addUsuario");
		String resultado = "index";

		if(!usuario.getName().equals("") && !usuario.getPasswd().equals("") && !usuario.getEmail().equals("")) {
			if(usuarioService.findByName(usuario.getName()) != null) {
				model.addAttribute("error","Este usuario ya existe");
				resultado = "errorNoVerificado";
			}else {
				if(usuario.getPasswd().equals(usuario.getConfirpasswd())) {
					usuarioService.crearUsuario(usuario);
					model.addAttribute("usuario",usuarioService.findByName(usuario.getName()));
				}else {
					model.addAttribute("error","La contraseña y su confirmación no coinciden");
					resultado = "errorNoVerificado";
				}
			}
		}else {
			model.addAttribute("usuario",usuarioService.findByName(usuario.getName()));
			model.addAttribute("error","No has introducido datos");
			resultado = "errorNoVerificado";
		}

		return resultado; 
	}

	@GetMapping("/login")    
	public String getloginUsuario(Usuario usuario, Model model){

		return "login";
	}



	@PostMapping("/login")    
	public String loginUsuario(Usuario usuario, Model model){
		System.out.println("\t UsuarioController::addUsuario");
		String resultado = "index";

		if(!usuario.getName().equals("") && !usuario.getPasswd().equals("")) {
			if(usuario.getName().equals("admin") && usuario.getPasswd().equals("admin")) {
				List<Usuario> usuarioList = (List<Usuario>) usuarioService.findAllUsers(); 
				model.addAttribute("usuarios", usuarioList.isEmpty() ? Collections.EMPTY_LIST : usuarioList);   
				resultado = "listarUsuarios";
			}else if(usuarioService.findByName(usuario.getName()) != null && usuarioService.findByName(usuario.getName()).getPasswd().equals(usuario.getPasswd())) {
				model.addAttribute("usuario",usuarioService.findByName(usuario.getName()));
				resultado = "index2";
			}else {
				model.addAttribute("error","No existe el usuario");
				resultado = "errorNoVerificado";
			}
		}else {
			model.addAttribute("error","No has introducido datos");
			resultado = "errorNoVerificado";
		}

		return resultado; 
	}


	@GetMapping("introducirDatosDieta/{id}")
	public String introducirDatosDieta(@PathVariable("id") Long usuarioId,Usuario usuario,Model model) {
		System.out.println("\t UsuarioController::introducirDatosDieta");
		model.addAttribute("usuario",usuarioService.findUsuarioById(usuarioId));
		Dieta d = new Dieta();
		model.addAttribute("dieta",d);
		return "introducirDatosDieta";
	}


	@PostMapping("recibirDatosDieta/{id}")
	public String recibirDatosDieta(@PathVariable("id") Long usuarioId,Usuario usuario,Dieta dieta,Model model) {
		System.out.println("\t UsuarioController::recibirDatosDieta");  
		String resultado = "errorDatos";
		model.addAttribute("usuario", usuarioService.findUsuarioById(usuarioId));

		if(!dieta.getNombre_dieta().equals("")) {
			Usuario u = usuarioService.findUsuarioById(usuarioId);
			u.setPeso(usuario.getPeso());
			u.setAltura(usuario.getAltura());
			u.setEdad(usuario.getEdad());
			u.setGenero(usuario.getGenero());

			Dieta d = dietaService.findByName(dieta.getNombre_dieta());
			u = usuarioService.findUsuarioById(usuarioId);

			d.addUsuario(u);
			dietaService.crearDieta(d);

			List<Comida> desayunos = new ArrayList<Comida>();
			List<Comida> comida_cena = new ArrayList<Comida>();

			for (Iterator<Comida> iterator = d.getComidas().iterator(); iterator.hasNext();) {
				Comida comida = (Comida) iterator.next();
				if(comida.getTipoComida().equals("Desayuno-Comida-Cena")) {
					desayunos.add(comida);
				}else if(comida.getTipoComida().equals("Comida-Cena")) {
					comida_cena.add(comida);
				}
			}

			model.addAttribute("desayunos", desayunos); 
			model.addAttribute("comida_cena", comida_cena);

			resultado = "mostrarComida";
		}

		return resultado;
	}


	@GetMapping("pedirDieta/{id}")
	public String pedirDieta(@PathVariable("id") Long usuarioId,Usuario u,Dieta dieta,Model model) {    	
		System.out.println("\t pedirDieta");
		return "recibirDieta";
	}


	@GetMapping("reciboDieta/{id}")
	public String recibirDieta(@PathVariable("id") Long usuarioId,Usuario usuario,Dieta dieta,Model model) {   

		try {
			usuario = usuarioService.findUsuarioById(usuarioId);
			Dieta d = dietaService.findByName(usuario.getDieta().getNombre_dieta());

			List<Comida> desayunos = new ArrayList<Comida>();
			List<Comida> comida_cena = new ArrayList<Comida>();

			for (Iterator<Comida> iterator = d.getComidas().iterator(); iterator.hasNext();) {
				Comida comida = (Comida) iterator.next();

				if(comida.getTipoComida().equals("Desayuno-Comida-Cena")) {
					desayunos.add(comida);
				}else if(comida.getTipoComida().equals("Comida-Cena")) {
					comida_cena.add(comida);
				}
			}

			model.addAttribute("desayunos", desayunos);
			model.addAttribute("comida_cena", comida_cena);
			model.addAttribute("usuario", usuarioService.findUsuarioById(usuarioId));
			model.addAttribute("error",false);
		}catch(NullPointerException e) {
			List<Comida> desayunos = new ArrayList<Comida>();
			List<Comida> comida_cena = new ArrayList<Comida>();
			model.addAttribute("desayunos", desayunos); 
			model.addAttribute("comida_cena", comida_cena);
			model.addAttribute("usuario", usuarioService.findUsuarioById(usuarioId));
			model.addAttribute("error",true);
		}


		return "mostrarComida";
	}



	@GetMapping("/addFavoritos/{id}/{nombre_comida}")
	public String anadirfavoritos(@PathVariable("id") Long usuarioId,@PathVariable("nombre_comida") String nombre_comida,Model model) {
		System.out.println("\t UsuarioController::anadirFavoritos");
		Comida c = comidaService.findByNombreComida(nombre_comida);
		Usuario u = usuarioService.findUsuarioById(usuarioId);
		boolean f = false;

		for (Iterator<Comida> iterator = u.getFavoritas().iterator(); iterator.hasNext();) {
			Comida comida = (Comida) iterator.next();
			if(comida.getNombre_comida().equals(c.getNombre_comida())) {
				f = true;
			}
		}

		if(f == false) {
			u.addFavorita(c);
			usuarioService.crearUsuario(u);
		}

		model.addAttribute("comidas", u.getFavoritas());
		model.addAttribute("usuario", usuarioService.findUsuarioById(usuarioId));


		return "mostrarFavoritos";
	}

	@GetMapping("/delFav/{id}/{nombre_comida}")
	public String eliminarfavoritos(@PathVariable("id") Long usuarioId,@PathVariable("nombre_comida") String nombre_comida,Model model) {
		System.out.println("\t UsuarioController::eliminarFavoritos");
		Comida c = comidaService.findByNombreComida(nombre_comida);
		Usuario u = usuarioService.findUsuarioById(usuarioId);

		u.eliminarFavorita(c);
		usuarioService.crearUsuario(u);

		model.addAttribute("comidas", u.getFavoritas());
		model.addAttribute("usuario", usuarioService.findUsuarioById(usuarioId));


		return "mostrarFavoritos";
	}

	@GetMapping("/mostrarfavoritos/{id}")
	public String mostraComidas(@PathVariable("id") Long usuarioId,Model model) {
		System.out.println("\t UsuarioController::mostrarFavoritos");  
		Usuario u = usuarioService.findUsuarioById(usuarioId);
		model.addAttribute("comidas", u.getFavoritas());
		model.addAttribute("usuario", u);

		return "mostrarFavoritos"; //devuelve la vista a renderizar
	}	

	@GetMapping("/verEnDetalle/{id}/{nombre_comida}")
	public String verEnDetalle(@PathVariable("id") Long usuarioId,@PathVariable("nombre_comida") String nombre_comida,Model model) {
		model.addAttribute("usuario",usuarioService.findUsuarioById(usuarioId));
		Comida comida = comidaService.findByNombreComida(nombre_comida);
		model.addAttribute("comida",comida);

		List<String> ingredientes = new ArrayList<String>();
		String[] parts;
		parts = comida.getIngredientes().split(",");
		for(int i = 0; i < parts.length; i++) {
			ingredientes.add(parts[i]);
		}

		model.addAttribute("ingredientes",ingredientes);


		return "verEnDetalle";
	}


	@GetMapping("/showUsuario/{id}")
	public String showUsuarioForm(@PathVariable("id") Long usuarioId, Model model) {
		System.out.println("\t UsuarioController::showUpdateUsuarioForm");    	
		model.addAttribute("usuario",usuarioService.findUsuarioById(usuarioId));
		return "mostrarUsuario";
	}

	//Html
	@GetMapping("/updateUsuario/{id}")
	public String showUpdateUsuarioForm(@PathVariable("id") Long usuarioId, Model model) {
		System.out.println("\t UsuarioController::showUpdateUsuarioForm");    	
		model.addAttribute("usuario",usuarioService.findUsuarioById(usuarioId));

		return "actualizarUsuario";
	}

	//para pasar parametros
	@PostMapping("/updateUsuario/{id}")
	public String updateUsuario(@PathVariable("id") Long usuarioId, Usuario usuario, Model model) {   	
		System.out.println("\n\t UsuarioController::updateUsuario");
		String resultado = "errorDatos";


		if(!usuario.getName().equals("") && !usuario.getEmail().equals("") && !usuario.getPasswd().equals("")) {

			if(usuario.getPasswd().equals(usuario.getConfirpasswd())) {
				resultado = "index2";
				try {
					if(usuarioService.findByName(usuario.getName()).getName().equals(usuarioService.findUsuarioById(usuarioId).getName())) {
						model.addAttribute("usuario", usuarioService.updateUsuario(usuario,usuarioId));
						model.addAttribute("error","Usuario Modificado");
						resultado = "errorDatos";
					}else {
						model.addAttribute("usuario",usuarioService.findUsuarioById(usuarioId));
						model.addAttribute("error","El nombre del usuario ya existe");
						resultado = "errorDatos";
					}
				}catch(NullPointerException e) {
					model.addAttribute("usuario", usuarioService.updateUsuario(usuario,usuarioId));
					model.addAttribute("error","Usuario Modificado");
					resultado = "errorDatos";
				}
			}else {
				model.addAttribute("usuario",usuarioService.findUsuarioById(usuarioId));
				model.addAttribute("error","La contraseña y su confirmación no coinciden");
			}

		}else {
			model.addAttribute("usuario",usuarioService.findUsuarioById(usuarioId));
			model.addAttribute("error","No es posible realizar esta operacion");
		}

		return resultado;    	
	}

	/**
	 * DELETE USUARIO
	 */
	@PostMapping("/deleteUsuario/{id}")
	public String deleteUsuario(@PathVariable("id") Long id, Model model) {
		System.out.println("\t usuarioController::deleteUsuario");

		if(!usuarioService.findUsuarioById(id).getName().equals("admin")) {
			Dieta d = usuarioService.findUsuarioById(id).getDieta();
			try {
				usuarioService.findUsuarioById(id).eliminarDieta(d);
				usuarioService.findUsuarioById(id).eliminarFavoritos();
			}catch(NullPointerException e) {

			}
			model.addAttribute("usuarios", usuarioService.deleteUsuarioById(id)); 
		}else {
			List<Usuario> usuarioList = (List<Usuario>) usuarioService.findAllUsers(); 
			model.addAttribute("usuarios", usuarioList.isEmpty() ? Collections.EMPTY_LIST : usuarioList);   
		}

		return "listarUsuarios";
	}
}
