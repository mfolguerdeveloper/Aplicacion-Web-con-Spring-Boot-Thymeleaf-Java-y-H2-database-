package com.example.data.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Dieta {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id_dieta;
	private String name;//vegana
	private String descripcion;//ideal para no matar animales
	
	@OneToMany (mappedBy ="dieta", cascade = CascadeType.ALL , fetch =
			FetchType.EAGER,orphanRemoval = true)
	private List<Usuario> usuarios = new ArrayList<Usuario>();
	

	@OneToMany (mappedBy ="dieta", cascade = CascadeType.ALL , fetch =
			FetchType.EAGER,orphanRemoval = true)
	private List<Comida> comidas = new ArrayList<Comida>();
	
	public Dieta() {
		name = "";
		descripcion = "";
	}
	
	public Dieta(String nombre_dieta, String descripcion) {
		this.name = nombre_dieta;
		this.descripcion = descripcion;
	}
	
	public List<Comida> getComidas() {
		return this.comidas;
	}

	public void setComidas(List<Comida> comidas) {
		this.comidas = comidas;
	}
	
	public void addComida(Comida c) {
		comidas.add(c);
		c.setDieta(this);
	}
	
	public void removeComida(Comida c) {
		comidas.remove(c);
		c.setDieta(null);
	}
	
	public void addUsuario(Usuario u) {
		usuarios.add(u);
		u.setDieta(this);
	}
	
	public void eliminarUsuario(Usuario u) {
		usuarios.remove(u);
		u.setDieta(null);
	}
	
	public String getDescripcion() {
		return descripcion;
	}


	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	public List<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	public String getNombre_dieta() {
		return name;
	}

	public void setNombre_dieta(String nombre_dieta) {
		this.name = nombre_dieta;
	}

	public void mostrarComidas() {
		Iterator<Comida> it = comidas.iterator();
		System.out.println(it.next().toString());
		while(it.hasNext()) {
			System.out.println(it.next().toString());
		}
	}
	
	@Override
	public String toString() {
		return "Dieta [id_dieta=" + id_dieta + ", nombre_dieta=" + name + ", descripcion=" + descripcion + "]";
	}

	
	

}
