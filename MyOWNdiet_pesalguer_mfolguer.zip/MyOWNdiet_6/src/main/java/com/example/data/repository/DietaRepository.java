package com.example.data.repository;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.example.data.model.Dieta;


@Repository
public interface DietaRepository extends CrudRepository<Dieta, Long> {
	Dieta findByName (String name);
}
