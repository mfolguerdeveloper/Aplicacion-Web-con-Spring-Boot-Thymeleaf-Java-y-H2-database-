package com.example.data.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.data.model.Usuario;
import com.example.data.repository.UsuarioRepository;
@Service
public class UsuarioServiceImpl implements UsuarioService {
 		
	private final UsuarioRepository usuarioRepository;
		
	@Autowired
	public UsuarioServiceImpl(UsuarioRepository usuarioRepository) {
		// TODO Auto-generated constructor stub
		System.out.println("\t Constructor UsuarioServiceImpl ");
		this.usuarioRepository = usuarioRepository;
		Usuario u=new Usuario("admin","admin",0,0,0,'m');
		u.setPasswd("admin");
		usuarioRepository.save(u);
	}
	
	@Override
	public Iterable<Usuario> crearUsuario(Usuario usuario) {		
		usuarioRepository.save(usuario);
		return findAllUsers();
	} 
	
	@Override
    public Usuario findUsuarioById(Long usuarioId) {
        return usuarioRepository.findById(usuarioId).get();
    }
	
	@Override
	public Iterable<Usuario> deleteUsuarioById(Long id) {		
		usuarioRepository.deleteById(id);
		return findAllUsers();
	}
	
	@Override
	public Usuario updateUsuario(Usuario usuario,Long usuarioId) {
		// TODO Auto-generated method stub
	    Usuario u = findUsuarioById(usuarioId);
	    
	    u.setName(usuario.getName());
	    u.setEmail(usuario.getEmail());
	    u.setPasswd(usuario.getPasswd());
	  
		usuarioRepository.save(u);
		return usuario;
	}

	
	@Override
	public Iterable<Usuario> updateNameAndEmailUsuario(Long id, String name, String email) {
		// TODO Auto-generated method stub
    	Usuario u = findUsuarioById(id);
    	u.setName(name);
    	u.setEmail(email);
    	usuarioRepository.save(u);
		return findAllUsers();
	}

	@Override
	public Iterable<Usuario> findAllUsers() {
		return usuarioRepository.findAll();		
	}
	
	public Usuario findByName(String name) {
		Usuario u = usuarioRepository.findByName(name);
		if(u == null) {
			return null;
		}
		
		return u;
		
	}

	


}
