package com.example.data.service;



import com.example.data.model.Usuario;

public interface UsuarioService {
	
	public Iterable <Usuario> crearUsuario(Usuario usuario);

	public Usuario findUsuarioById (Long usuarioId);

	public Iterable<Usuario> deleteUsuarioById(Long id);
	
	public Usuario updateUsuario(Usuario usuario,Long usuarioId);
	
	public Iterable<Usuario> updateNameAndEmailUsuario(Long id, String name, String email);
	
	public Iterable <Usuario> findAllUsers();
	
	public Usuario findByName(String name);

}