package com.example.data.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.data.model.Comida;
import com.example.data.repository.ComidaRepository;



@Service
public class ComidaServiceImpl implements ComidaService{
	
	private final ComidaRepository comidaRepository;
	
	@Autowired
	public ComidaServiceImpl(ComidaRepository comidaRepository) {
		// TODO Auto-generated constructor stub
		System.out.println("\t Constructor ComidaServiceImpl ");
		this.comidaRepository = comidaRepository;
	}
	
	public Comida findByNombreComida(String nombre_comida) {
		Comida c = comidaRepository.findByName(nombre_comida);
		return c;	
	}
	

}
