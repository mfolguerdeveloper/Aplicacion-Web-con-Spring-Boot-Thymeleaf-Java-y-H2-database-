package com.example.data.service;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.data.model.Comida;
import com.example.data.model.Dieta;
import com.example.data.repository.DietaRepository;

@Service
public class DietaServiceImpl implements DietaService{
	
	private final DietaRepository dietaRepository;
	
	
	
	
	@Autowired
	public DietaServiceImpl(DietaRepository dietaRepository) {
		// TODO Auto-generated constructor stub
		System.out.println("\t Constructor DietaServiceImpl ");
		this.dietaRepository = dietaRepository;
		inicializarDietas();
	}
	
	public void inicializarDietas() {
		Dieta d = new Dieta("Vegetariana","Una dieta vegetariana se enfoca a la alimentación con verduras. Esto incluye frutas, verduras, guisantes y alubias secas, granos, semillas y nueces. No existe un único tipo de dieta vegetariana.");
		Dieta d1 = new Dieta("Mediterranea","La dieta mediterránea es el modo de alimentarse basado en la cocina tradicional de la cuenca mediterránea.​");
		Dieta d2 = new Dieta("Proteica","La dieta proteinada es una dieta que representa un aporte de proteínas ajustado a los requerimientos del organismo, baja en hidratos de carbono y en lípidos.");
		List<Comida> comidas = iniciarComidas();
		
		
		for (Iterator<Comida> iterator = comidas.iterator(); iterator.hasNext();) {
			Comida comida = (Comida) iterator.next();
			if(comida.getTipoDieta().equals("Vegetariana")) {
				d.addComida(comida);
			}else if(comida.getTipoDieta().equals("Mediterranea")) {
				d1.addComida(comida);
			}else if(comida.getTipoDieta().equals("Proteica")) {
				d2.addComida(comida);
			}	
			
		}
		
		

		
		dietaRepository.save(d);
		dietaRepository.save(d1);
		dietaRepository.save(d2);
	}
	
	public List<Comida> iniciarComidas() {
		
		//--------------------------------------------------VEGETARIANAS--------------------------------------------------
				Comida Setas_crujientes=new Comida("Setas crujientes","Setas ostras-200g"
								+ ",Huevo-1"
								+ ",Queso parmesano-25g,"
								+ ",Sal-al gusto"
								+ ",Ajo en polvo-1 cucharada"
								+ ",Hierbas provenzales-1 cucharada"
								+ ",Pimienta negra molida-1/2 cucharitas"
								+ ",Panko-2 cucharadas,Leche-1 cucharada"
								,"11 minutos"
								,"https://www.directoalpaladar.com/videos-recetas/setas-crujientes-freidora-aire-receta-vegetariana-para-cena-complicaciones-tiempo-record"
								,"Setascrujientes.jpg"
								,"Vegetariana"
								,"Comida-Cena"
								,"251kcal");

				Comida Espaguetis_con_verduras=new Comida("Espaguetis con verduras"
						,"Espaguetis-400 g,"
								+ "Cebolla blanca-1,"
								+ "Zanahoria medianas-2,"
								+ "Calabacín grande-1,"
								+ "Berenjena grande-1,"
								+ "Hongos secos-6 a 8 unidades,"
								+ "Salsa de soja-40 ml,"
								+ "Jengibre molido-opcional,"
								+ "Pimienta negra molida-10 g,"
								+ ",Aceite de sésamo-5 ml"
								+ ",Semillas de sésamo-15 g"
								+ ",Cebollino-puñado generoso"
								+ ",Aceite de oliva virgen extra-al gusto"
								,"50 minutos"
								,"https://www.directoalpaladar.com/recetas-vegetarianas/espaguetis-verduras-receta-facil-rapida-nutritiva-pasta-que-resuelve-almuerzo-cuando-hay-poco-tiempo-ganas"
								,"Espaguetisconverduras.jpg"
								,"Vegetariana"
								,"Comida-Cena"
								,"565kcal");
				Comida Hummus_verde=new Comida("Hummus verde"
						,"Espaguetis-400 g,"
								+ "Garbanzos frescos o de conserva-40 g,"
								+ "Guisantes frescos o de conserva-120 g,"
								+ "Limón ralladura y zumo-1,"
								+ "Tahini-15ml,"
								+ "Aceite de oliva-30 ml,"
								+ "Sal y pimienta-al gusto,"
								+ "Comino molido-opcional,"
								+ "Menta fresca-opcional"
								,"15 minutos"
								,"https://www.directoalpaladar.com/recetas-de-aperitivos/hummus-verde-alternativa-para-picoteo-muy-facil-saludable-guisantes"
								,"Hummusverde.jpg"
								,"Vegetariana"
								,"Desayuno-Comida-Cena"
								,"105kcal");

				Comida Arroz_5_delicias=new Comida("Arroz 5 delicias"
						,"Arroz-250 g,"
								+ "Cebolla pequeña-1,"
								+ "Cebolla de primavera-1,"
								+ "Zanahoria mediana-1,"
								+ "Guisantes cocidos-50 g,"
								+ "Garbanzos cocidos-80 g,"
								+ "Salsa de soja-20ml,"
								+ "Aceite de oliva virgen extra-10 ml,"
								+ "Aceite de sesamo-opcional,"
								+ "Cacahuetes picados-opcional,"
								+ "Jengibre molido-5 g,"
								+ "Pimienta negra molida-al gusto,"
								+ "Pimenton dulce-5 g"
								,"25 minutos"
								,"https://www.directoalpaladar.com/recetas-de-arroces/arroz-cinco-delicias-combinacion-excepcional-ingredientes-para-plato-rapido-completo-integral"
								,"Arroz5delicias.jpg"
								,"Vegetariana"
								,"Comida-Cena"
								,"405kcal");
				Comida Ñoquis_con_camembert_y_uvas=new Comida("Ñoquis con camembert y uvas"
						,"Ñoquis-450 g,"
								+ "Repollo-200 g,"
								+ "Puerro-1,"
								+ "Diente de ajo-1,"
								+ "Leche-325 ml,"
								+ "Queso crema-225 g,"
								+ "Queso cheddar-75 g,"
								+ "Uvas sin pepitas-18,"
								+ "Queso Camembert-125 g,"
								+ "Aceite de oliva virgen extra-al gusto,"
								+ "Sal-al gusto,"
								+ "Pimienta negra molida-al gusto,"
								+ "Nuez moscada molida-al gusto,"
								+ "Nueces picadas-50 g"
								,"60 minutos"
								,"https://www.directoalpaladar.com/recetas-de-pasta/gnocchi-noquis-camembert-uvas-receta-facil-para-comida-socorrida-contundente"
								,"Nioquisconcamembertyuvas.jpg"
								,"Vegetariana"
								,"Comida-Cena"
								,"560kcal");
				
				Comida Arroz_de_coliflor=new Comida("Arroz de coliflor"
						,"Coliflor mediana-1,"
								+ "Zanahoria-2,"
								+ "Puerro-1,"
								+ "Cebolla-1,"
								+ "Almendras-40 g,"
								+ "Garam masala -al gusto,"
								+ "Cúrcuma molida-al gusto,"
								+ "Caldo de verduras-50 ml,"
								+ "Salsa de soja-al gusto,"
								+ "Aceite de oliva virgen extra-al gusto,"
								+ "Sal-al gusto,"
								+ "Pimienta negra molida-al gusto"
								,"25 minutos"
								,"https://www.directoalpaladar.com/recetas-de-legumbres-y-verduras/arroz-coliflor-receta-curry-para-hacer-colirroz-frito-pollo"
								,"Arrozdecoliflor.jpg"
								,"Vegetariana"
								,"Comida-Cena"
								,"360kcal");
				
				Comida Macarrones_con_salsa_de_batata=new Comida("Macarrones con salsa de batata"
						,"Batata grande-1,"
								+ "Yogur natural-45 g,"
								+ "Leche-250 ml,"
								+ "Levadura nutricional-20 g,"
								+ "Almendras-40 g,"
								+ "Pimentón dulce-10 g,"
								+ "Cúrcuma molida-15 g,"
								+ "Mostaza de Dijon-10 ml,"
								+ "Cebolla en polvo-10 g,"
								+ "Aceite de oliva virgen extra-al gusto,"
								+ "Sal-al gusto,"
								+ "Pasta corta-200 g,"
								+ "Cebollino-30 g,"
								+ "Pimienta negra-al gusto"
								,"45 minutos"
								,"https://www.directoalpaladar.com/recetas-vegetarianas/macarrones-salsa-batata-boniato-yogur-natural-leche-receta-facil-perfecta-para-dias-verano"
								,"Macarronesconsalsadebatata.jpg"
								,"Vegetariana"
								,"Comida-Cena"
								,"680kcal");
				//--------------------------------------------------PROTEICA--------------------------------------------------

				Comida Ensalada_de_garbanzos_con_tomate_y_ventresca_de_atún=new Comida("Ensalada de garbanzos con tomate y ventresca de atún"
						,"Garbanzos cocidos en conserva-300 g,"
								+ "Tomate cherry de tres variedades-200 g,"
								+ "Rabanitos-6,"
								+ "Cebolla morada-1,"
								+ "Aceitunas negras-325 ml,"
								+ "Aceitunas negras-20,"
								+ "Apio-1,"
								+ "Ventresca de atún en conserva-250 g,"
								+ "Aceite de oliva virgen extra-90 ml,"
								+ "Vinagre de vino blanco-30 ml,"
								+ "Mostaza de Dijon cucharadas soperas-2,"
								+ "Miel cucharada sopera-1,"
								+ "Tomillo fresco al gusto-al gusto,"
								+ "Sal-al gusto,"
								+ "Pimienta-al gusto"
								,"10 minutos"
								,"https://www.directoalpaladar.com/recetas-de-ensaladas/ensalada-primaveral-de-garbanzos-con-tomates-y-ventresca-de-atun"
								,"Ensaladadegarbanzoscontomateyventrescadeatun.jpg"
								,"Proteica"
								,"Comida-Cena"
								,"600kcal");
				
				Comida Huevos_turcos_con_yogur=new Comida("Huevos turcos con yogur"
						,"Yogur griego natural-125g,"
								+ "Medio diente de ajo-al gusto,"
								+ "Perejil-al gusto,"
								+ "Eneldo-al gusto,"
								+ "Cilandro-al gusto,"
								+ "Pimienta negra-al gusto,"
								+ "Pimienton Dulce-al gusto,"
								+ "Sal-al gusto,"
								+ "Huevo-1,"
								+ "Aceite de oliva virgen extra-al gusto,"
								+ "Sal en escamas-abundante"
								,"20 minutos"
								,"https://www.vitonica.com/recetas-saludables/huevos-turcos-con-yogur-receta-saludable"
								,"Huevosturcosconyogur.jpg"
								,"Proteica"
								,"Desayuno-Comida-Cena"
								,"200kcal");
				
				Comida Pollo_caprese_al_estilo_hasselback=new Comida("Pollo caprese al estilo hasselback"
						,"Pechuga de pollo no muy grandes-2,"
								+ "Mozzarella fresca-1,"
								+ "Tomate-2,"
								+ "Albahaca fresca-6,"
								+ "Ajo granulado-al gusto,"
								+ "Pimienta negra molida-al gusto,"
								+ "Pimienton Dulce-al gusto,"
								+ "Sal-al gusto"
								,"45 minutos"
								,"https://www.directoalpaladar.com/recetas-de-carnes-y-aves/pollo-caprese-al-estilo-hasselback-receta-para-unas-pechugas-diferentes"
								,"Pollocapresealestilohasselback.jpg"
								,"Proteica"
								,"Comida-Cena"
								,"400kcal");
				
				Comida Lomo_a_la_sal_con_salsa_de_naranja=new Comida("Lomo a la sal con salsa de naranja"
						,"Lomo de cerdo-600,"
								+ "Pimienta negra molida-al gusto,"
								+ "Sal gruesa-1000g,"
								+ "Romero fresco rama-1,"
								+ "Aceite de oliva virgen extra-30 ml,"
								+ "Cebolla-100 g,"
								+ "Vino blanco-50 ml,"
								+ "Harina de maíz refinada-10 g,"
								+ "Mermelada de naranja amarga-30 g,"
								+ "Caldo de pollo-200 ml,"
								+ "Extracto de carne-5 g"
								,"45 minutos"
								,"https://www.directoalpaladar.com/recetas-de-carnes-y-aves/lomo-a-la-sal-en-microondas-con-salsa-de-naranja-receta"
								,"Lomoalasalconsalsadenaranja.jpg"
								,"Proteica"
								,"Comida-Cena"
								,"630kcal");
				
				Comida Sardinas_al_horno_con_perejil=new Comida("Sardinas al horno con perejil"
						,"Sardinas frescas-1000 g,"
								+ "Limon-2,"
								+ "Dientes de ajo-2,"
								+ "Perejil fresco rama-4,"
								+ "Aceite de oliva virgen extra-al gusto,"
								+ "Pimienta negra molida-al gusto,"
								+ "Sal gruesa-al gusto"
								,"20 minutos"
								,"https://www.directoalpaladar.com/recetas-de-pescados-y-mariscos/sardinas-al-horno-con-perejil-receta"
								,"Sardinasalhornoconperejil.jpg"
								,"Proteica"
								,"Comida-Cena"
								,"630kcal");
				
				Comida Redondo_de_pavo_y_manzana=new Comida("Redondo de pavo y manzana"
						,"Redondo de pavo-1,"
								+ "Manzanas Golden-2,"
								+ "Cebolla-2,"
								+ "Zanahoria-4,"
								+ "Caldo de verduras-200 ml,"
								+ "Aceite de oliva virgen extra-al gusto,"
								+ "Pimienta negra molida-al gusto,"
								+ "Sal-al gusto"
								,"40 minutos"
								,"https://www.directoalpaladar.com/recetas-de-carnes-y-aves/redondo-de-pavo-y-manzana-en-olla-a-presion-receta-libre-de-grasas"
								,"Redondodepavoymanzana.jpg"
								,"Proteica"
								,"Comida-Cena"
								,"410kcal");
				Comida Brochetas_de_pollo_estilo_Satay=new Comida("Brochetas de pollo estilo Satay"
						,"Pechuga de pollo-2,"
								+ "Salsa de soja-150 ml,"
								+ "Limón-1,"
								+ "Curry molido-20 g,"
								+ "Jengibre molido-5 g,"
								+ "Sal de ajo-5 g,"
								+ "Cúrcuma molida-5 g,"
								+ "Semillas de sésamo-10 g,"
								+ "Aceite de girasol-15 ml,"
								+ "Sal-al gusto,"
								+ "Pimienta negra molida-al gusto"
								,"25 minutos"
								,"https://www.directoalpaladar.com/tapas-y-pinchos/brochetas-de-pollo-estilo-satay-receta-para-el-picoteo"
								,"BrochetasdepolloestiloSatay.jpg"
								,"Proteica"
								,"Comida-Cena"
								,"490kcal");

				//--------------------------------------------------MEDITERRANEA--------------------------------------------------
				Comida Cachopo_asturiano=new Comida("Cachopo asturiano"
						,"Filetes de ternera-4,"
								+ "Jamón serrano en lonchas-100 g,"
								+ "Queso para fundir-100 g,"
								+ "Huevos-2,"
								+ "Pan rallado-50 g"
								,"25 minutos"
								,"https://www.directoalpaladar.com/recetas-de-carnes-y-aves/receta-cachopo-asturiano-ternera-jamon-queso"
								,"Cachopoasturiano.jpg"
								,"Mediterranea"
								,"Comida-Cena"
								,"890kcal");
				Comida Receta_de_cocido_madrileño=new Comida("Receta de cocido madrileño"
						,"Garbanzos-300 g,"
								+ "Morcillo-400 g,"
								+ "Tocino-200 g,"
								+ "Hueso de rodilla de ternera-2,"
								+ "Huesos de espinazo de cerdo salado-3,"
								+ "Hueso de caña con tuétano-3,"
								+ "Chorizo fresco-3,"
								+ "Fideos cabellín-150 g,"
								+ "Gallina-150 ml,"
								+ "Patatas-3,"
								+ "Zanahoria-2"
								,"20 minutos"
								,"https://www.directoalpaladar.com/recetas-de-legumbres-y-verduras/receta-de-cocido-madrileno"
								,"Recetadecocidomadrilenio.jpg"
								,"Mediterranea"
								,"Comida-Cena"
								,"970kcal");
				Comida Lentejas_guisadas=new Comida("Lentejas guisadas"
						,"Lentejas-250 g,"
								+ "Pimiento verde-100 g,"
								+ "Cebolla-80 g,"
								+ "Puerro-70 g,"
								+ "Zanahoria-100 g,"
								+ "Patata-250 g,"
								+ "Salsa de tomate-50 g,"
								+ "Aceite de oliva virgen -al gusto,"
								+ "Diente de ajo-1,"
								+ "Laurel-al gusto,"
								+ "Sal-al gusto,"
								+ "Pimenton dulce-al gusto"
								,"75 minutos"
								,"https://www.directoalpaladar.com/recetas-de-legumbres-y-verduras/como-hacer-lentejas-guisadas-receta"
								,"Lentejasguisadas.jpg"
								,"Mediterranea"
								,"Comida-Cena"
								,"870kcal");
				Comida  Merluza_a_la_romana_rebozada=new Comida("Merluza a la romana rebozada"
						,"Merluza en rodajas-4,"
								+ "Huevo-2,"
								+ "Sal-al gusto,"
								+ "Harina de trigo(para albaldar el pescado)-20 g,"
								+ "Aceite de girasol(para freir)-15 ml"
								,"15 minutos"
								,"https://www.directoalpaladar.com/recetas-de-pescados-y-mariscos/como-hacer-merluza-a-romana-receta-ideal-para-cenar"
								,"Merluzaalaromanarebozada.jpg"
								,"Mediterranea"
								,"Comida-Cena"
								,"760kcal");
				
				Comida Sepia_al_horno_con_patatas=new Comida("Sepia al horno con patatas"
						,"Sepia-400 g,"
								+ "Cebolla dulce-1,"
								+ "Diente de ajo-2,"
								+ "Curry molido-20 g,"
								+ "Vino blanco-200 g,"
								+ "Limón-1,"
								+ "Pimentón dulce-al gusto,"
								+ "Tomillo seco-al gusto,"
								+ "Perejil fresco-al gusto,"
								+ "Sal-al gusto,"
								+ "Aceite de oliva virgen extra-al gusto,"
								+ "Patata medianas-2,"
								+ "Pimienta negra molida-al gusto"
								,"60 minutos"
								,"https://www.directoalpaladar.com/recetas-de-pescados-y-mariscos/sepia-al-horno-con-patatas-receta"
								,"Sepiaalhornoconpatatas.jpg"
								,"Mediterranea"
								,"Comida-Cena"
								,"380kcal");
				Comida San_Jacobos_de_berenjena_y_salmón=new Comida("San Jacobos de berenjena y salmón"
						,"Salmón fresco-400 g,"
								+ "Berenjena-1,"
								+ "Queso en lonchas-8,"
								+ "Pan rallado-al gusto,"
								+ "Aceite de oliva virgen extra-al gusto"
								,"30 minutos"
								,"https://www.directoalpaladar.com/recetas-de-pescados-y-mariscos/san-jacobos-de-berenjena-rellena-de-salmon-receta"
								,"SanJacobosdeberenjenaysalmon.jpg"
								,"Mediterranea"
								,"Comida-Cena"
								,"680kcal");
				Comida Brochetas_de_melón_con_crujiente_de_jamón=new Comida("Brochetas de melón con crujiente de jamón"
						,"Melon-1/2,"
								+ "Loncha de Jamon Serrano-4"
								,"15 minutos"
								,"https://www.directoalpaladar.com/navidad/brochetas-melon-crujiente-jamon-para-aperitivo-navideno-ligero-refrescante-receta-facil-rapida"
								,"Brochetasdemelonconcrujientedejamon.jpg"
								,"Mediterranea"
								,"Comida-Cena"
								,"180kcal");
				
				List<Comida> comidas = new ArrayList<Comida>();
				
				
			
				comidas.add(Arroz_5_delicias);
				comidas.add(Arroz_de_coliflor);
				comidas.add(Brochetas_de_melón_con_crujiente_de_jamón);
				comidas.add(Brochetas_de_pollo_estilo_Satay);
				comidas.add(Cachopo_asturiano);
				comidas.add(Ensalada_de_garbanzos_con_tomate_y_ventresca_de_atún);
				comidas.add(Espaguetis_con_verduras);
				comidas.add(Huevos_turcos_con_yogur);
				comidas.add(Hummus_verde);
				comidas.add(Lentejas_guisadas);
				comidas.add(Lomo_a_la_sal_con_salsa_de_naranja);
				comidas.add(Macarrones_con_salsa_de_batata);
				comidas.add(Merluza_a_la_romana_rebozada);
				comidas.add(Pollo_caprese_al_estilo_hasselback);
				comidas.add(Receta_de_cocido_madrileño);
				comidas.add(Redondo_de_pavo_y_manzana);
				comidas.add(San_Jacobos_de_berenjena_y_salmón);
				comidas.add(Sardinas_al_horno_con_perejil);
				comidas.add(Sepia_al_horno_con_patatas);
				comidas.add(Setas_crujientes);
				comidas.add(Ñoquis_con_camembert_y_uvas);
				
				return comidas;
				
		}
	
	
	@Override
	public void crearDieta(Dieta d) {		
		dietaRepository.save(d);
		//return dietaRepository.findById(1L);
	}
	
	public Dieta findByName(String name) {
		Dieta d = dietaRepository.findByName(name);
		return d;	
	}
	
	public List<Comida> findByDieta(String dieta){
		Dieta d = dietaRepository.findByName(dieta);
	    List<Comida> comidas = (List<Comida>) d.getComidas();
		return comidas;
	}


	

}
