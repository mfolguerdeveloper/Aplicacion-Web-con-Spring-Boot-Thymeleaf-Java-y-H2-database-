package com.example.data.model;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;


@Entity
public class Comida {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id_comida;
	private String name;
	@Column(length = 500)
	private String ingredientes;
	private String tiempoPreparacion;
	private String imagen;
	private String enlace;
	private String tipoDieta;
	private String tipoComida;//Desayuno,Comida,Cena
	private String valorNutricional;
	
	@ManyToOne
	private Dieta dieta;
	
	@ManyToMany(fetch = FetchType.EAGER)
	private List<Usuario> usuarios = new ArrayList<Usuario>();
	
	
	public Comida() {
		name = "";
		ingredientes = "";
		tipoDieta = "";
		tipoComida = "";
		enlace = "";
		imagen = "";
		valorNutricional = "";
	}

	public Comida( String nombre_comida, String ingredientes, String tiempoPreparacion, String enlace,
			String imagen, String tipoDieta, String tipoComida, String valorNutricional) {
		
		this.name = nombre_comida;
		this.ingredientes = ingredientes;
		this.tiempoPreparacion = tiempoPreparacion;
		this.enlace = enlace;
		this.imagen = imagen;
		this.tipoDieta = tipoDieta;
		this.tipoComida = tipoComida;
		this.valorNutricional = valorNutricional;

	}

	
	
	public long getId_comida() {
		return id_comida;
	}

	public void setId_comida(long id_comida) {
		this.id_comida = id_comida;
	}

	public String getNombre_comida() {
		return name;
	}

	public void setNombre_comida(String nombre_comida) {
		this.name = nombre_comida;
	}

	public String getIngredientes() {
		return ingredientes;
	}

	public void setIngredientes(String ingredientes) {
		this.ingredientes = ingredientes;
	}

	public String getTipoDieta() {
		return tipoDieta;
	}

	public void setTipoDieta(String tipoDieta) {
		this.tipoDieta = tipoDieta;
	}

	public String getValorNutricional() {
		return valorNutricional;
	}

	public void setValorNutricional(String valorNutricional) {
		this.valorNutricional = valorNutricional;
	}
	
	public String getTipoComida() {
		return tipoComida;
	}

	public void setTipoComida(String tipoComida) {
		this.tipoComida = tipoComida;
	}

	public Dieta getDieta() {
		return dieta;
	}

	public void setDieta(Dieta dieta) {
		this.dieta = dieta;
	}

	public String getTiempoPreparacion() {
		return tiempoPreparacion;
	}

	public void setTiempoPreparacion(String tiempoPreparacion) {
		this.tiempoPreparacion = tiempoPreparacion;
	}
	
	public String getEnlace() {
		return enlace;
	}

	public void setEnlace(String enlace) {
		this.enlace = enlace;
	}
	
	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public List<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}
	
	public void addUsuario(Usuario u) {
		usuarios.add(u);
		u.getFavoritas().add(this);
	}
	
	public void eliminarFavorito(Usuario u) {
		this.getUsuarios().remove(u);
		u.getFavoritas().remove(this);
	}

	@Override
	public String toString() {
		return "Comida [id_comida=" + id_comida + ", nombre_comida=" + name + ", ingredientes=" + ingredientes
				+ ", tipoDieta=" + tipoDieta + ", tipoComida=" + tipoComida + ", valorNutricional=" + valorNutricional
				+ ", dieta=" + dieta + "]";
	}

}
