package com.example.data.service;

import java.util.List;
import com.example.data.model.Dieta;
import com.example.data.model.Comida;

public interface DietaService {

	void crearDieta(Dieta d);
	
	Dieta findByName(String name);
	
	List<Comida> findByDieta(String dieta);
	
	

}
