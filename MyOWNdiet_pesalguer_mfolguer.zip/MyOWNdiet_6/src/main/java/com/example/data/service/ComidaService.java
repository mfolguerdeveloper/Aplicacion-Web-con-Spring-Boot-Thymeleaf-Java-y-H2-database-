package com.example.data.service;

import com.example.data.model.Comida;

public interface ComidaService {
	
	public Comida findByNombreComida(String nombre_comida);
	
	
}
