package com.example.data;

import java.util.Iterator;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.data.model.Comida;
import com.example.data.model.Dieta;
import com.example.data.model.Usuario;
import com.example.data.repository.ComidaRepository;
import com.example.data.repository.DietaRepository;
import com.example.data.repository.UsuarioRepository;

@SpringBootTest
class RelacionesBd1ApplicationTests {
	@Autowired
	private UsuarioRepository usuarioRepository; 

	@Autowired
	private DietaRepository dietaRepository;

	@Autowired
	private ComidaRepository comidaRepository;


	@Test
	public void crear() {

	}
}
